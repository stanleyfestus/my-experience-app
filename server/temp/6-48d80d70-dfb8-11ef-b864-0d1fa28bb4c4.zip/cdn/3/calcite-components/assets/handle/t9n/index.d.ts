export type HandleMessages = {
  dragHandle: string;
  dragHandleUntitled: string;
  dragHandleActive: string;
  dragHandleChange: string;
  dragHandleCommit: string;
  dragHandleIdle: string;
};
